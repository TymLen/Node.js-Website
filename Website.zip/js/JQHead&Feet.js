//JQHead&Feet.js
$(function(){
	$("#navbar").load("/navbar");
});
$(function(){
	$("footer").load("/footer");
});