//JQPro.js

$(document).ready(function(){
	GetData("project");
});
$("overlay").click(function(){
	overlayOff();
});