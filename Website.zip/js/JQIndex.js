//JQPro.js

$(document).ready(function(){
			GetData("home");
});