//JQPro.js

$(document).ready(function(){
	GetSkills();
});
